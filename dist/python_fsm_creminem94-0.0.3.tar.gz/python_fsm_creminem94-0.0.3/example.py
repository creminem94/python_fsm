from python_fsm_creminem94.StateHandler import StateHandler, StateLink, RobotState
from enum import Enum

class FsmState(Enum):
    INIT = 0
    MOVE = 1
    WORK = 2

def test():
    def condition():
        return True

    def pre():
        print("pre")

    def exec():
        print("exec")

    def post():
        print("post")

    states = [
        RobotState(FsmState.INIT, [
            StateLink(FsmState.MOVE, condition)
        ], pre),
        RobotState(FsmState.MOVE, [
            StateLink(FsmState.WORK, condition)
        ], pre, exec, post),
        RobotState(FsmState.WORK, [
            StateLink(FsmState.INIT, condition)
        ], pre, exec, post),
    ]

    stateHandler = StateHandler(states, FsmState.INIT, logger=print)


if __name__ == "__main__":
    test()