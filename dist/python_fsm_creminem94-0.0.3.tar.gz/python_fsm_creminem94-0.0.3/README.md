# Python FSM
This package contains a set of classes to handle a Finite State Machine (FSM).

